﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLHSUNGTUYEN.NhanVien.BLL
{
    internal class HinhThucDT
    {
        public int MaHT;
        public string TenHT;
        public string MoTa;
        public int GiaTien; 

        public HinhThucDT()
        {
        }
    }
}
